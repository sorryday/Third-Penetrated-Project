package com.gumi.enjoytrip.util;

public class SizeConstant {

	public final static int LIST_SIZE = 12;
	public final static int NAVIGATION_SIZE = 10;

}
